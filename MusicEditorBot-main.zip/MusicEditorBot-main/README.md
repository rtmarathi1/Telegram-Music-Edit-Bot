# Music Editor Bot

A Telegram bot to change the music tags and artwork.

## Deploy to Heroku
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/samadii/MusicEditorBot)





